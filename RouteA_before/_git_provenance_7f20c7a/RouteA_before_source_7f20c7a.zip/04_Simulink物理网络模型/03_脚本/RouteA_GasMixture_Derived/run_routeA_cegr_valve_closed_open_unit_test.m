function result = run_routeA_cegr_valve_closed_open_unit_test()
% Test the official CEGR valve constituent laws in disposable two-reservoir networks.
% The main-model Variant wrapper is checked separately by model_read/model_check.

testPrefix = 'RouteA_CEGRValveConstitutiveUnitTest';
oldDir = pwd;
cleanup = onCleanup(@() cd(oldDir));
load_system('FuelCell_lib');

result = struct();
result.closedForward = runFixture(testPrefix, "closed", 105000, 100000);
result.closedReverse = runFixture(testPrefix, "closed", 100000, 105000);
result.openForward = runFixture(testPrefix, "open", 105000, 100000);

result.closedForwardPassed = isClosed(result.closedForward, 1);
result.closedReversePassed = isClosed(result.closedReverse, -1);
result.openForwardPassed = result.openForward.finite && ...
    result.openForward.mdot_kg_s > 1e-9 && ...
    result.openForward.deltaP_Pa > 1e3;
result.passed = result.closedForwardPassed && result.closedReversePassed && ...
    result.openForwardPassed;
assignin('base', 'routeA_cegr_valve_closed_open_unit_test', result);

if ~result.passed
    error('RouteA:CEGRValveConstitutiveUnitTestFailed', ...
        'The CEGR valve closed/open constituent test did not meet its gates.');
end
clear cleanup;
end

function state = runFixture(testPrefix, mode, pUp_Pa, pDown_Pa)
testModel = char(testPrefix + "_" + mode + "_" + ...
    string(pUp_Pa) + "_" + string(pDown_Pa));
if bdIsLoaded(testModel)
    close_system(testModel, 0);
end
cleanup = onCleanup(@() closeFixture(testModel));
new_system(testModel);

add_block('nesl_utility/Solver Configuration', [testModel '/Solver']);
add_block('FuelCell_lib/utilities/Gas Mixture Properties (FC)', ...
    [testModel '/GasProperties']);
add_block('FuelCell_lib/elements/Reservoir (FC)', ...
    [testModel '/ReservoirUp'], 'p0', sprintf('%.16g', pUp_Pa), ...
    'T0', '293.15', 'y0', '[0.79;0.21;0;0]', ...
    'area', '0.00196349540849362');
add_block('FuelCell_lib/elements/Reservoir (FC)', ...
    [testModel '/ReservoirDown'], 'p0', sprintf('%.16g', pDown_Pa), ...
    'T0', '293.15', 'y0', '[0.79;0.21;0;0]', ...
    'area', '0.00196349540849362');
add_block('FuelCell_lib/sensors/Mass Flow Rate Sensor (FC)', ...
    [testModel '/FlowSensor']);
add_block('FuelCell_lib/sensors/Pressure and Temperature Sensor (FC)', ...
    [testModel '/PressureUp']);
add_block('FuelCell_lib/sensors/Pressure and Temperature Sensor (FC)', ...
    [testModel '/PressureDown']);
add_block('FuelCell_lib/elements/Absolute Reference (FC)', ...
    [testModel '/PressureUpRef']);
add_block('FuelCell_lib/elements/Absolute Reference (FC)', ...
    [testModel '/PressureDownRef']);

if mode == "closed"
    add_block('FuelCell_lib/elements/Infinite Flow Resistance (FC)', ...
        [testModel '/Valve']);
else
    add_block('FuelCell_lib/elements/Local Restriction (FC)', ...
        [testModel '/Valve'], 'area', '0.00196349540849362', ...
        'max_area', '9.81747704246811e-05', 'min_area', '1e-10', ...
        'restriction_area', '5e-05', ...
        'const_area', 'false', 'Cd', '0.64', 'B_lam', '0.999');
    add_block('simulink/Sources/Constant', [testModel '/AreaCommand'], ...
        'Value', '5e-05');
    add_block('nesl_utility/Simulink-PS Converter', [testModel '/AreaPS'], ...
        'Unit', 'm^2');
    connectSignal(testModel, 'AreaCommand', 1, 'AreaPS', 1);
    connectPhysical(testModel, 'AreaPS', 'RConn', 'Valve', 'AR');
end

addMeasurementChain(testModel, 'MdotPS', 'MdotToWorkspace', ...
    'routeA_valve_test_mdot');
addMeasurementChain(testModel, 'PhiPS', 'PhiToWorkspace', ...
    'routeA_valve_test_phi');
addMeasurementChain(testModel, 'SpeciesPS', 'SpeciesToWorkspace', ...
    'routeA_valve_test_species');
addMeasurementChain(testModel, 'PUpPS', 'PUpToWorkspace', ...
    'routeA_valve_test_p_up');
addMeasurementChain(testModel, 'PDownPS', 'PDownToWorkspace', ...
    'routeA_valve_test_p_down');

connectPhysical(testModel, 'GasProperties', 'A', 'Solver', 'RConn');
connectPhysical(testModel, 'GasProperties', 'A', 'ReservoirUp', 'A');
connectPhysical(testModel, 'ReservoirUp', 'A', 'FlowSensor', 'A');
connectPhysical(testModel, 'FlowSensor', 'B', 'Valve', 'A');
connectPhysical(testModel, 'Valve', 'B', 'ReservoirDown', 'A');
connectPhysical(testModel, 'ReservoirUp', 'A', 'PressureUp', 'A');
connectPhysical(testModel, 'PressureUp', 'B', 'PressureUpRef', 'A');
connectPhysical(testModel, 'ReservoirDown', 'A', 'PressureDown', 'A');
connectPhysical(testModel, 'PressureDown', 'B', 'PressureDownRef', 'A');
connectPhysical(testModel, 'FlowSensor', 'M', 'MdotPS', 'LConn');
connectPhysical(testModel, 'FlowSensor', 'Phi_out', 'PhiPS', 'LConn');
connectPhysical(testModel, 'FlowSensor', 'M_i', 'SpeciesPS', 'LConn');
connectPhysical(testModel, 'PressureUp', 'P', 'PUpPS', 'LConn');
connectPhysical(testModel, 'PressureDown', 'P', 'PDownPS', 'LConn');
connectSignal(testModel, 'MdotPS', 1, 'MdotToWorkspace', 1);
connectSignal(testModel, 'PhiPS', 1, 'PhiToWorkspace', 1);
connectSignal(testModel, 'SpeciesPS', 1, 'SpeciesToWorkspace', 1);
connectSignal(testModel, 'PUpPS', 1, 'PUpToWorkspace', 1);
connectSignal(testModel, 'PDownPS', 1, 'PDownToWorkspace', 1);

out = sim(testModel, 'StopTime', '0.05', 'ReturnWorkspaceOutputs', 'on');
state = struct();
state.mode = mode;
state.pUpSet_Pa = pUp_Pa;
state.pDownSet_Pa = pDown_Pa;
state.mdot_kg_s = lastValue(out.get('routeA_valve_test_mdot'));
state.phi_W = lastValue(out.get('routeA_valve_test_phi'));
state.speciesMdot_kg_s = lastValue(out.get('routeA_valve_test_species'));
state.pUp_Pa = lastValue(out.get('routeA_valve_test_p_up'));
state.pDown_Pa = lastValue(out.get('routeA_valve_test_p_down'));
state.deltaP_Pa = state.pUp_Pa - state.pDown_Pa;
state.finite = all(isfinite([state.mdot_kg_s; state.phi_W; ...
    state.speciesMdot_kg_s(:); state.pUp_Pa; state.pDown_Pa]));
clear cleanup;
end

function tf = isClosed(state, expectedDeltaSign)
flowTolerance = 1e-12;
energyTolerance = 1e-9;
tf = state.finite && abs(state.mdot_kg_s) <= flowTolerance && ...
    abs(state.phi_W) <= energyTolerance && ...
    all(abs(state.speciesMdot_kg_s(:)) <= flowTolerance) && ...
    expectedDeltaSign * state.deltaP_Pa > 1e3;
end

function addMeasurementChain(model, converter, sink, variableName)
add_block('nesl_utility/PS-Simulink Converter', [model '/' converter]);
add_block('simulink/Sinks/To Workspace', [model '/' sink], ...
    'VariableName', variableName, 'SaveFormat', 'Timeseries');
end

function value = lastValue(series)
data = series.Data;
timeCount = numel(series.Time);
if isscalar(data)
    value = data;
elseif size(data, 1) == timeCount
    value = squeeze(data(end, :, :));
elseif ndims(data) >= 2 && size(data, ndims(data)) == timeCount
    index = repmat({':'}, 1, ndims(data));
    index{end} = timeCount;
    value = squeeze(data(index{:}));
else
    value = data(end);
end
end

function connectSignal(model, source, sourcePort, destination, destinationPort)
add_line(model, [source '/' num2str(sourcePort)], ...
    [destination '/' num2str(destinationPort)], 'autorouting', 'on');
end

function connectPhysical(model, source, sourcePort, destination, destinationPort)
sourceHandle = physicalPort([model '/' source], sourcePort);
destinationHandle = physicalPort([model '/' destination], destinationPort);
add_line(model, sourceHandle, destinationHandle, 'autorouting', 'on');
end

function handle = physicalPort(block, portName)
ports = get_param(block, 'PortHandles');
switch portName
    case 'A'
        if contains(string(get_param(block, 'MaskType')), 'Local Restriction')
            handle = ports.LConn(2);
        else
            handle = ports.LConn(1);
        end
    case 'AR'
        handle = ports.LConn(1);
    case 'B'
        handle = ports.RConn(end);
    case 'M'
        handle = ports.RConn(1);
    case 'Phi_out'
        handle = ports.RConn(2);
    case 'M_i'
        handle = ports.RConn(3);
    case 'P'
        handle = ports.RConn(1);
    case 'RConn'
        handle = ports.RConn(1);
    case 'LConn'
        handle = ports.LConn(1);
    otherwise
        error('RouteA:UnknownPhysicalPort', ...
            'Unknown test-fixture physical port: %s.', portName);
end
end

function closeFixture(testModel)
if bdIsLoaded(testModel)
    close_system(testModel, 0);
end
end
